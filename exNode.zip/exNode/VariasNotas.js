/*Crie um script em Node.js que permita ao usuário digitar várias notas (ex: 7.5, 6, 10...), uma por vez, até digitar "fim".
No final, o programa deve calcular e exibir:

✅ A média das notas
📈 A maior nota
📉 A menor nota
*/

let readline = require("readline");
let rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function perguntar(pergunta) {
    return new Promise((resolve) => {
        rl.question(pergunta, (resposta) => {
            resolve(resposta);
        });
    });
}

async function main() {
    let boletim = [];

    while (true) {
        let nota = await perguntar("Digite uma nota (ou 'sair' para encerrar): ");
        if (nota.toLowerCase() === "sair") {
            break;
        }
        console.log(boletim)
        let numero = parseFloat(nota);
        if (!isNaN(numero)) {
            boletim.push(numero);
        } else {
            console.log("⚠️ Entrada inválida. Digite um número.");
        }
    }

    if (boletim.length > 0) {
        let soma = boletim.reduce((acumulador, valorAtual) => acumulador + valorAtual, 0);
        let media = soma / boletim.length;
        let maior = Math.max(...boletim);
        let menor = Math.min(...boletim);

        console.log(`\n✅ Média das notas: ${media.toFixed(1)}`);
        console.log(`📈 Maior nota: ${maior.toFixed(1)}`);
        console.log(`📉 Menor nota: ${menor.toFixed(1)}`);
    } else {
        console.log("\nNenhuma nota válida foi digitada.");
    }

    rl.close();
}

main();
