const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function perguntar(pergunta) {
  return new Promise((resolve) => {
    rl.question(pergunta, (resposta) => {
      resolve(resposta);
    });
  });
}

async function main() {
  let temperatura = parseFloat(await perguntar("Digite a temperatura: "));
  let converter = await perguntar("Converter para (C/F)? ");

  if (isNaN(temperatura) || (converter.toLowerCase() !== "C" && converter !== "F")) {
    console.log("❌ Dados incorretos!");
    rl.close();
    return;
  }

  if (converter.toLowerCase() === "C") {
    let celsius = (temperatura - 32) * 5 / 9;
    console.log(`🌡️ ${temperatura}°F em Celsius é: ${celsius.toFixed(1)}°C`);
  } else if (converter.toLowerCase() === "F") {
    let fahrenheit = (temperatura * 9 / 5) + 32;
    console.log(`🌡️ ${temperatura}°C em Fahrenheit é: ${fahrenheit.toFixed(1)}°F`);
  }

  rl.close();
}

main();
