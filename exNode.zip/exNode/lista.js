/*Crie um script que permita ao usuário digitar vários itens de uma lista de compras, um por vez, e salve tudo em um arquivo .txt.*/
let readline = require("readline");
let fs = require("fs");
let rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
function perguntar(pergunta){
    return new Promise((resolve) =>{
        rl.question(pergunta, (resposta) => {
            resolve(resposta);
        });
    });
}
async function main() {
    let lista = [];
        while (true){
             let produto = await perguntar("Digite um item (ou 'sair' para finalizar): ");
             if(produto.toLowerCase() === 'sair') break;
             lista.push(produto);
             console.log(`${lista}`)
    }
    
fs.writeFileSync("lista.txt", lista.join('\n'));
console.log('Lista salva no arquivo lista.txt');


    rl.close();
}
main();

