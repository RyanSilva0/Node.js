/*🎯 Objetivo:
Crie um script que rode no terminal e:

Peça ao usuário 3 notas usando entrada via terminal

Calcule a média aritmética

Mostre no console:

A média final

A mensagem:

“✅ Aprovado” se a média ≥ 7

“⚠️ Recuperação” se a média entre 5 e 6.9

“❌ Reprovado” se a média < 5

*/

let readline = require("readline");

let = rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function perguntar(pergunta){
    return new Promise((resolve) =>{
        rl.question(pergunta, (resposta) => {
            resolve(resposta);
        });
    });
}
async function main() {
    let n1 = parseFloat(await perguntar("Digite a primeira nota: "))
    let n2 = parseFloat(await perguntar("Digite a segunda nota: "))
    let n3 = parseFloat(await perguntar("Digite a terceira nota: "))

    let media = (n1 + n2 + n3) / 3
    console.log(`\nMédia: ${media.toFixed(1)}`);

    if(media >= 7){
        console.log("✅ Aprovado");
    }
    else if (media => 5 ) {
        console.log("⚠️ Recuperação");
    }
    else{
        console.log("❌ Reprovado");
    }
    rl.close();
}
main();
