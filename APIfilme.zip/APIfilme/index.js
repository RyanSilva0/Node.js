/* 
Criar uma API REST que permita:

Listar filmes

Adicionar filmes

Editar filmes

Deletar filmes

Sem banco de dados — tudo em memória (array). Ideal pra treinar lógica de CRUD.

mkdir api-filmes
cd api-filmes
npm init -y
npm install express cors
*/
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

let filmes = [

    { id: 1, titulo: "Matrix", diretor: "Wachowski", ano: 1999 },
    { id: 2, titulo: "Vingadores", diretor: "Joss Whedon", ano: 2012 }
];

//get 
app.get('/filmes', (req, res) => {
  res.json(filmes);
});
//get por ID
app.get('/filmes/:id', (req, res) =>{
    const filme = filmes.find(f => f.id == req.params.id);
    if (!filme) return res.status(404).send("Filme não encontrado.");
    res.json(filme);
});
//Post
app.post('/filmes', (req, res) =>{
    const {titulo, diretor, ano } = req.body;
    const novofilme = {
        id: Date.now(),
        titulo,
        diretor,
        ano
    };
    filmes.push(novoFilme);
    res.status(201).json(novofilme);
});
//put
app.put('/filmes/:id', (req, res) =>{
    const {id} = req.params;
    const {titulo, diretor, ano} = req.body;
    
    const index = filmes.findIndex(f => f.id == id);
    if (index === -1) return res.status(404).send("Filme não encontrado.");

    filmes[index] = {
        ...filmes[index], titulo, diretor, ano
    };
    res.json(filmes[index]);
});

//DELETE
app.delete('/filmes/:id', (req, res) =>{
    const { id } = req.params;
    const antes = filmes.length;
    filmes = filmes.filter(f => f.id != id);
    if(filmes.length === antes) return res.status(404).send("Filme não encontrado");
    res.status(204).send();
});

app.listen(3000, () =>{
    console.log("🔥 API rodando na quebrada http://localhost:3000");
});



