let readline = require("readline");
let fs = require("fs");

let rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function perguntar(pergunta) {
    return new Promise((resolve) => {
        rl.question(pergunta, (resposta) => {
            resolve(resposta);
        });
    });
}

async function main() {
    let erros = 0;
    let numeroAleatorio = Math.floor(Math.random() * 100) + 1;

    while (true) {
        let tentativa = await perguntar("Adivinhe o número entre 1 e 100: ");

        if (tentativa.trim() === "") {
            console.log("⚠️ Nenhum valor foi digitado!");
            break;
        }

        let playerNumber = parseFloat(tentativa);

        if (isNaN(playerNumber)) {
            console.log("⚠️ Valor inválido. Digite um número.");
            continue;
        }

        erros++;

        if (playerNumber < numeroAleatorio) {
            console.log("🔻 Muito baixo!");
        } else if (playerNumber > numeroAleatorio) {
            console.log("🔺 Muito alto!");
        } else {
            console.log(`🎯 Parabéns! Você acertou em ${erros} tentativa(s)!`);

            // 🎯 Ranking
            let nome = await perguntar("Digite seu nome para salvar no ranking: ");

            let ranking = [];

            try {
                if (fs.existsSync("ranking.json")) {
                    let dados = fs.readFileSync("ranking.json", "utf8");
                    ranking = JSON.parse(dados);
                }
            } catch (erro) {
                console.log("❌ Erro ao ler o ranking:", erro.message);
            }

            // Adiciona novo resultado
            ranking.push({ nome: nome.trim(), tentativas: erros });

            // Salva ranking atualizado
            try {
                fs.writeFileSync("ranking.json", JSON.stringify(ranking, null, 2));
                console.log("✅ Ranking atualizado com sucesso!");
            } catch (erro) {
                console.log("❌ Erro ao salvar o ranking:", erro.message);
            }

            break;
        }
    }

    rl.close();
}

main();
