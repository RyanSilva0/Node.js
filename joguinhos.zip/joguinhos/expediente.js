const fetch = require('node-fetch');

const TIMEZONE = 'America/Sao_Paulo';
const INICIO = 7;
const FIM =16;

async function pegarHorarioAtual() {
  try {
    const res = await fetch(`http://worldtimeapi.org/api/timezone/${TIMEZONE}`);
    const data = await res.json();
    return new Date(data.datetime);
  } catch (error) {
    console.warn('⚠️ Não foi possível pegar horário da internet, usando horário local!');
    return new Date();
  }
}

function calcularProgresso(agora) {
  const inicio = new Date(agora);
  inicio.setHours(INICIO, 0, 0, 0);

  const fim = new Date(agora);
  fim.setHours(FIM, 0, 0, 0);

  if (agora < inicio) return 0;
  if (agora > fim) return 100;

  const total = fim - inicio;
  const passado = agora - inicio;
  return Math.floor((passado / total) * 100);
}

function gerarBarra(percentual, largura = 30) {
  const preenchido = Math.floor((percentual / 100) * largura);
  const vazio = largura - preenchido;
  return `[${'█'.repeat(preenchido)}${' '.repeat(vazio)}] ${percentual}%`;
}

(async () => {
  const agora = await pegarHorarioAtual();
  const progresso = calcularProgresso(agora);
  console.log(`\nExpediente 07:00 às 16:00`);
  console.log(`Agora: ${agora.toLocaleTimeString()}`);
  console.log(gerarBarra(progresso));
})();
