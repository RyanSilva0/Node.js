const http = require('http');
const url = require('url');
const port = 3000;

const server = http.createServer((req, res) => {
    
    if (req.url === '/favicon.ico') {
        res.writeHead(204); 
        res.end();
        return; 
    }

    console.log('Requisição para:', req.url); 
    const queryObject = url.parse(req.url, true).query;
    console.log(queryObject);
    const nome = queryObject['nome'];

    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(`Bem vindo ao Node! gerei uma resposta http! ${nome}\n`);

    
}).listen(port);

console.log('Servidor rodando na porta 3000');